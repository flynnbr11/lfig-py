# lfig - Latex figures from matplotlib

## Overview 
This package provides a single utility - a class which wraps functionality for ensuring 
matplotlib figures align nicely with latex documents. 
